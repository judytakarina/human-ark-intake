# Human Ark — Venture Intake Form

Standalone intake form for humanark.eu, deployable to Vercel in ~5 minutes.

---

## Step 1 — Set up Formspree (email integration)

1. Go to **https://formspree.io** and sign up for a free account
2. Click **"New Form"** → name it "Human Ark Venture Intake"
3. Set the destination email to **info@humanark.eu**
4. Copy the form endpoint — it looks like: `https://formspree.io/f/abcd1234`
5. Open `src/App.jsx` and replace line 6:
   ```
   const FORMSPREE_ENDPOINT = "https://formspree.io/f/YOUR_FORM_ID";
   ```
   with your actual endpoint, e.g.:
   ```
   const FORMSPREE_ENDPOINT = "https://formspree.io/f/abcd1234";
   ```

---

## Step 2 — Deploy to Vercel

### Option A: Via GitHub (recommended)

1. Create a free account at **https://github.com** if you don't have one
2. Create a new repository called `human-ark-intake`
3. Upload all files from this folder to the repository
4. Go to **https://vercel.com** → sign up with GitHub
5. Click **"Add New Project"** → import your `human-ark-intake` repo
6. Vercel auto-detects Vite — just click **"Deploy"**
7. Your form is live at e.g. `human-ark-intake.vercel.app`

### Option B: Via Vercel CLI

```bash
npm install -g vercel
cd human-ark-intake
npm install
vercel
```

Follow the prompts — your URL will appear at the end.

---

## Custom domain (optional)

To use `intake.humanark.eu`:
1. In Vercel → Project Settings → Domains → Add `intake.humanark.eu`
2. Add a CNAME record in your DNS: `intake` → `cname.vercel-dns.com`

---

## Local development

```bash
npm install
npm run dev
```

Opens at http://localhost:5173
